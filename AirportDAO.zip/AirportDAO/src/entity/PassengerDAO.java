/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import core.DB;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author Shane D
 */
public class PassengerDAO implements DAO<Passenger> {
    
    List<Passenger> Passengers;

    @Override
    public List<Agent> getAll() {
        List<Agent> agents = new ArrayList<>();
        try {
            String sql = "SELECT * FROM Agents";
            try (PreparedStatement stmt = DB.getInstance().getPreparedStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {
                
                while (rs.next()) {
                    Agent agent = new Agent(
                            rs.getString("AgentID"), 
                            rs.getString("FirstName"), 
                            rs.getString("LastName"), 
                            rs.getString("PhoneNumber"), 
                            rs.getString("Agency")
                    );
                    agents.add(agent);
                }
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
        return agents;
    }
    
    
    @Override
    public Optional<Agent> get (String id) {
       DB db = DB.getInstance();
        ResultSet rs = null;
        try {
            String sql = "SELECT * FROM Agents WHERE AgentID = ?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setString(1, id);
            rs = stmt.executeQuery();
            Agent agent = null;
            while (rs.next()) {
                agent = new Agent(rs.getString("AgentID"), rs.getString("FirstName"), rs.getString("LastName"), rs.getString("PhoneNumber"), rs.getString("Agency"));
            }
            return Optional.ofNullable(agent);
        } catch (SQLException ex) {
            System.err.println(ex.toString());
            return null;
        }
    
    }
    
    @Override
    public void insert(Passenger passenger)
    {
        DB db = DB.getInstance();
        try {
            String sql = "INSERT INTO Passenger (AgentID, FirstName, LastName, PhoneNumber, Agency) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setInt(1, passenger.getID());
            stmt.setString(2, passenger.getFirstName());
            stmt.setString(3, passenger.getLastName());
            stmt.setInt(4, passenger.CheckInLocationID);
            stmt.setDate(5, passenger.CheckInDateTime);
            int rowInserted = stmt.executeUpdate();
            if (rowInserted > 0) {
                System.out.println("A new Passenger was inserted successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Update a contact entity in database if it exists using a contact object
     * @param contact
     */
    @Override
    public void update(Passenger passenger) {
        DB db = DB.getInstance();
        try {
            String sql = "UPDATE Passenger SET FirstName=?, LastName=?, PhoneNumber=?, Agency=? WHERE AgentID=?";
            PreparedStatement stmt = db.getPreparedStatement(sql);

            stmt.setInt(1, passenger.getID());
            stmt.setString(2, passenger.getFirstName());
            stmt.setString(3, passenger.getLastName());
            stmt.setString(4, passenger.getAgency()); // Assuming you want to include the Agency field in your update.
            stmt.setString(5, agent.getAgentID()); // Using AgentID as the last parameter for the WHERE clause.

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("An existing agent was updated successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Delete a contact from contact table if the entity exists
     * @param agent 
     */
    @Override
    public void delete(Agent agent) {
        DB db = DB.getInstance();
        try {
            // Ensure the table name is correctly referenced as "Agents" (plural) if that's your schema.
            String sql = "DELETE FROM Agents WHERE AgentID = ?";
            PreparedStatement stmt = db.getPreparedStatement(sql);
            stmt.setString(1, agent.getAgentID());
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("An agent was deleted successfully!");
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
    }
    
    /**
     * Get all column names in a list array
     * @return 
     */
    @Override
    public List<String> getColumnNames() {
        DB db = DB.getInstance();
        List<String> headers = new ArrayList<>();
        try {
            // Adjust the SQL query to target the "Agents" table.
            // Using a query that selects no rows to just fetch the metadata.
            String sql = "SELECT * FROM Agents WHERE 1=0";
            ResultSet rs = db.executeQuery(sql);
            ResultSetMetaData rsmd = rs.getMetaData();

            // Get number of columns in the result set and add their names to the headers list.
            int numberCols = rsmd.getColumnCount();
            for (int i = 1; i <= numberCols; i++) {
                headers.add(rsmd.getColumnLabel(i));
            }
        } catch (SQLException ex) {
            System.err.println(ex.toString());
        }
        return headers;
    }    
    
    
    
}
