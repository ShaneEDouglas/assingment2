/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author Shane D
 */
public class CheckinLocation {
    
    int CheckInLocationID;
    String StationName;
    
    
    public CheckinLocation(int checkinlocationid, String stationname) {
        
        this.CheckInLocationID = checkinlocationid;
        this.StationName = stationname;
    
    }

    public int getCheckInLocationID() {
        return CheckInLocationID;
    }

    public void setCheckInLocationID(int CheckInLocationID) {
        this.CheckInLocationID = CheckInLocationID;
    }

    public String getStationName() {
        return StationName;
    }

    public void setStationName(String StationName) {
        this.StationName = StationName;
    }
    
    @Override
    public String toString(){
        return "CheckinLocation { " + "CheckInLocationID=" + CheckInLocationID + ", StationName=" + StationName + '}';
    }
    
}
