/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.sql.Date;



/**
 *
 * @author Shane D
 */
public class Passenger 

{
    
    int ID;
    String FirstName;
    String LastName;
    int CheckInLocationID;
    Date CheckInDateTime;

    public Passenger(int ID, String FirstName, String LastName, int CheckInLocationID, Date CheckInDateTime) {
        this.ID = ID;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.CheckInLocationID = CheckInLocationID;
        this.CheckInDateTime = CheckInDateTime;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public int getCheckInLocationID() {
        return CheckInLocationID;
    }

    public void setCheckInLocationID(int CheckInLocationID) {
        this.CheckInLocationID = CheckInLocationID;
    }

    public Date getCheckInDateTime() {
        return CheckInDateTime;
    }

    public void setCheckInDateTime(Date CheckInDateTime) {
        this.CheckInDateTime = CheckInDateTime;
    }
    
    @Override
    public String toString() {
        return "Passenger {" + "ID=" + ID + ", firstname=" + FirstName + ", lastname=" + LastName + ", checkinlocationid=" + CheckInLocationID + ", CheckinDateTime=" + CheckInDateTime + '}';
    }

    
    
}
