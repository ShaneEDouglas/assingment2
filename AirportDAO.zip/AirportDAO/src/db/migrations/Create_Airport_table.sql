/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/SQLTemplate.sql to edit this template
 */
/**
 * Author:  Shane D
 * Created: Mar 13, 2024
 */

CREATE TABLE CheckinLocation (
CheckInLocationID INT,
StationName VARCHAR(30) NOT NULL,
PRIMARY KEY(CheckinLocationID) 
);

CREATE TABLE Passenger (
ID INT,
FirstName VARCHAR(30) NOT NULL ,
LastName  VARCHAR(30) NOT NULL,
CheckInLocationID INT NOT NULL,
CheckInDateTime DATE NOT NULL,

PRIMARY KEY(ID), 
FOREIGN KEY (CheckInLocationID) REFERENCES CheckinLocation(CheckInLocationID)
);





