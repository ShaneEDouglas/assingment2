CREATE TABLE Contact (  
    id INT PRIMARY KEY,
    firstname VARCHAR(30) NOT NULL,
    lastname VARCHAR(30) NOT NULL,
    phonenumber VARCHAR(20) NOT NULL
);